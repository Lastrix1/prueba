package lautaro.busico.p1.pkg322;

public class Ala extends Pieza implements Ajustable {

    private int cargaAerodinamica;
    private final static int maximo = 10;
    private final static int minimo = 1;

    public Ala(int cargaAerodinamica, String nombre, String ubicacion, CondicionClimatica condicionClimatica) throws CargaExcedida {
        super(nombre, ubicacion, condicionClimatica);
        if (verificarCargaCorecta(cargaAerodinamica)) {
            throw new CargaExcedida("la carga aerodinamica esta fuera del limite");
        }
        this.cargaAerodinamica = cargaAerodinamica;
    }

    public int getCargaAerodinamica() {
        return cargaAerodinamica;
    }

    @Override
    public void ajustar() {
        System.out.println("la pieza : " + this.getNombre() + " fue ajustada correctamente");
    }

    @Override
    public String toString() {
        return "Ala{" + super.toString() + "cargaAerodinamica=" + cargaAerodinamica + ", Maximo=" + maximo + ", Minimo=" + minimo + '}';
    }

    private boolean verificarCargaCorecta(int piezaACargar) {

        return (piezaACargar > maximo || piezaACargar < minimo);

    }

}
