package lautaro.busico.p1.pkg322;

public class Neumatico extends Pieza {

    private Compuesto compuesto;

    public Neumatico(Compuesto compuesto, String nombre, String ubicacion, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacion, condicionClimatica);
        this.compuesto = compuesto;
    }

    public Compuesto getCompuesto() {
        return compuesto;
    }

}
