package lautaro.busico.p1.pkg322;

public class LautaroBusicoP1322 {

    public static void main(String[] args) throws PiezaExistente {

        Box sistema = new Box();

        Motor m1 = new Motor(950, "PU-016", "Estacion Motor", CondicionClimatica.SECO);
        Motor m2 = new Motor(920, "PU-017", "Estacion Motor", CondicionClimatica.MIXTO);

        Ala a1 = new Ala(8, "Ala-Delantera-1", "Estacion Aero", CondicionClimatica.SECO);
        Ala a2 = new Ala(6, "Ala-Trasera-1", "Estacion Aero", CondicionClimatica.MOJADO);

        Neumatico n1 = new Neumatico(Compuesto.SOFT, "Pirelli-SOFT-01", "Carro Neumaticos", CondicionClimatica.SECO);
        Neumatico n2 = new Neumatico(Compuesto.WET, "Pirelli-WET-01", "Carro Neumaticos", CondicionClimatica.MOJADO);

        System.out.println("=== AGREGANDO PIEZAS ===");

        try {
            sistema.agregarPieza(m1);
            sistema.agregarPieza(m2);
            sistema.agregarPieza(a1);
            sistema.agregarPieza(a2);
            sistema.agregarPieza(n1);
            sistema.agregarPieza(n2);

            System.out.println("\nIntento de agregar pieza duplicada:");

            sistema.agregarPieza(m2);

        } catch (PiezaExistente e) {
            System.out.println(" " + e.getMessage());
        }
        separador();

        System.out.println("=== MOSTRAR PIEZAS ===");
        sistema.mostrarPiezas();

        separador();

        System.out.println("=== AJUSTANDO PIEZAS ===");
        sistema.ajustarPiezas();

        separador();

        System.out.println("=== BUSCAR PIEZAS PARA SECO ===");
        sistema.buscarPiezaPorCondicion(CondicionClimatica.SECO);

        System.out.println("=== BUSCAR PIEZAS PARA LLUVIA ===");
        sistema.buscarPiezaPorCondicion(CondicionClimatica.MOJADO);

        separador();

        System.out.println("=== BUSCAR PIEZAS PARA MIXTO ===");
        sistema.buscarPiezaPorCondicion(CondicionClimatica.MIXTO);
        separador();
        
    }
    

    private static void separador() {
        System.out.println("\n----------------------------------------------\n");
    }
}
