package lautaro.busico.p1.pkg322;

public enum Compuesto {
    SOFT,
    MEDIUM,
    HARD,
    WET;
}
