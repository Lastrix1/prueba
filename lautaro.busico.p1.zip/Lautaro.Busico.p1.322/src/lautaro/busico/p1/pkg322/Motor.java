
package lautaro.busico.p1.pkg322;


public class Motor extends Pieza implements Ajustable{
    private double potenciaMaxima;

    public Motor(double potenciaMaxima, String nombre, String ubicacion, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacion, condicionClimatica);
        this.potenciaMaxima = potenciaMaxima;
    }

    public double getPotenciaMaxima() {
        return potenciaMaxima;
    }


    @Override
    public void ajustar() {
        System.out.println("la pieza : "+this.getNombre()+" fue ajustada correctamente");
    }

    @Override
    public String toString() {
        return "Motor{"+super.toString() + "potenciaMaxima=" + potenciaMaxima + '}';
    }
    
    
    
}
