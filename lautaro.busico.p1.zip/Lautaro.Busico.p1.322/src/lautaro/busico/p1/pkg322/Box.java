package lautaro.busico.p1.pkg322;

import java.util.ArrayList;

public class Box {

    private ArrayList<Pieza> listaDePiezas = new ArrayList<>();

    public void agregarPieza(Pieza pieza) throws PiezaExistente {
        if (listaDePiezas.contains(pieza)) {
            throw new PiezaExistente("la pieza: " + pieza.getNombre() + " en la ubicacion: " + pieza.getUbicacion() + " ya existe");
        }
        listaDePiezas.add(pieza);

    }

    public void mostrarPiezas() {
        for (Pieza pieza : listaDePiezas) {
            System.out.println(pieza.toString());
        }
    }

    public void ajustarPiezas() {
        for (Pieza pieza : listaDePiezas) {
            if (!(pieza instanceof Ajustable)) {
                System.out.println("Los neumaticos No se pueden ajustar");
                continue;
            }
            ((Ajustable) pieza).ajustar();
        }
    }

    public void buscarPiezaPorCondicion(CondicionClimatica condicion) {
        int contador = 0;
        for (Pieza pieza : listaDePiezas) {
            if (pieza.getCondicionClimatica().equals(condicion)) {
                System.out.println(pieza.toString());
                contador++;
            }

        }
        if (contador == 0) {
            System.out.println("ninguna pieza se a encontrado con el la condicion climatica de " + condicion);
        }
    }

}
