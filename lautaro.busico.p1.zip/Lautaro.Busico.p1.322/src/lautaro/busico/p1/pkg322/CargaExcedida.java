
package lautaro.busico.p1.pkg322;


public class CargaExcedida extends IllegalArgumentException {
    CargaExcedida(String mensaje){
        super(mensaje);
    }
    
}
