
package lautaro.busico.p1.pkg322;


public class Pieza {
    String nombre;
    String ubicacion;
    CondicionClimatica condicionClimatica;

    public Pieza(String nombre, String ubicacion, CondicionClimatica condicionClimatica) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.condicionClimatica = condicionClimatica;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public CondicionClimatica getCondicionClimatica() {
        return condicionClimatica;
    }

    public boolean equals(Pieza pieza){
        if(this.getNombre().equals(pieza.getNombre()) && this.getUbicacion().equals(pieza.getUbicacion())){
            return true;
        }
        return false;
    }
        
    public String Mostrar(){
       StringBuilder sb = new StringBuilder();
        sb.append("la pieza: " + this.getNombre());
        sb.append(" en la ubicacion: "+this.getUbicacion());
        sb.append(" y la condicion Climatica ideal es: "+this.getCondicionClimatica());
        return sb.toString();
    }
    @Override    
    public String toString(){
        return this.Mostrar();
    }

}
